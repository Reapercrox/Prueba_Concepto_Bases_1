﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

namespace TP1
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            PageBody.Attributes.Add("bgcolor", "003d33");
        }
        SqlConnection con = new SqlConnection(@"Data Source = BRETONDESKTOP\SQLEXPRESS; Initial Catalog = TareaProgramada1; Persist Security Info=True;User ID = sa; Password=password22");
        protected void btn_Logout_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Index.aspx");
        }

        protected void btn_Regresar_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Productos.aspx");
        }
        protected bool VNombre(string Nombre)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SP_VNombre", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Connection.Open();
                cmd.Parameters.Add("@Nombre", SqlDbType.VarChar, 128).Value = Nombre;
                
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lbl_Error.Text = "Ya existe un artículo con este nombre";
                    con.Close();
                    return false;

                }
                else
                {
                    con.Close();
                    return true;
                }
            }
            catch (Exception err)
            {
                lbl_Error.Text = "Ocurrió un error inesperado en la Base de Datos";
                return false;
            }
            finally
            {
                con.Close();
            }
        }
        protected void btn_Insertar_Click(object sender, EventArgs e)
        {
            if (VNombre(txt_Nombre.Text))
            {
                if (txt_Nombre.Text == "" || txt_Precio.Text == "")
                {
                    lbl_Error.Text = "Uno o más campos están vacíos";
                }
                else
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand("SP_INS_Articulo", con)
                        {
                            CommandType = CommandType.StoredProcedure
                        };
                        cmd.Connection.Open();
                        cmd.Parameters.Add("@Nombre", SqlDbType.VarChar, 128).Value = txt_Nombre.Text;
                        cmd.Parameters.Add("@Precio", SqlDbType.Money).Value = txt_Precio.Text;
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.Read())
                        {
                            lbl_Error.Text = "No se realizó la inserción";

                        }
                        else
                        {
                            lbl_Error.Text = "Articulo insertado correctamente";
                        }
                    }
                    catch (Exception err)
                    {
                        lbl_Error.Text = "Ocurrió un error inesperado en la Base de Datos";
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }
    }
}